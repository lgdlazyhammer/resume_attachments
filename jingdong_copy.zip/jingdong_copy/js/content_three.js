$(function(){
	
	$(".content_three").find(".left_panel_content").find(".left_panel_sub_content").hide();
	
	$(".content_three").find(".left_panel_content").find(".left_panel_sub_tag").on("mouseover",function(){
		
		$(this).parent().parent().find(".left_panel_sub_content").hide();
		$(this).parent().parent().find(".left_panel_sub_tag").css("color","lightgrey");
		$(this).css("color","black");
		$(this).parent().parent().find(".left_panel_sub_content").eq($(this).attr("title")).show();
	});
	
	$(".content_three").find(".left_panel_tag").on("mouseover",function(){
		
		$(".content_three").find(".left_panel_tag").css("background","#009f96");
		$(".content_three").find(".left_panel_tag").css("color","white");
		
		$(this).css("background","white");
		$(this).css("color","#009f96");
		
		$(".content_three").find(".left_panel_content").hide();
		$(".content_three").find(".left_panel_content").eq($(this).attr("title")).show();
	});
	
	
	/* 为触发页面初始化 */
	$(".content_three").find(".left_panel_content").find(".left_panel_sub_tag").on("click",function(){
		
		$(this).parent().parent().find(".left_panel_sub_content").hide();
		$(this).parent().parent().find(".left_panel_sub_tag").css("color","lightgrey");
		$(this).css("color","black");
		$(this).parent().parent().find(".left_panel_sub_content").eq($(this).attr("title")).show();
	});
	
	$(".content_three").find(".left_panel_tag").on("click",function(){
		
		$(".content_three").find(".left_panel_tag").css("background","#009f96");
		$(".content_three").find(".left_panel_tag").css("color","white");
		
		$(this).css("background","white");
		$(this).css("color","#009f96");
		
		$(".content_three").find(".left_panel_content").hide();
		$(".content_three").find(".left_panel_content").eq($(this).attr("title")).show();
	});
	
	$(".content_three").find(".left_panel_tag").eq(0).click();
	$(".content_three").find(".left_panel_content").find(".left_panel_sub_tag").eq(0).click();
	
});