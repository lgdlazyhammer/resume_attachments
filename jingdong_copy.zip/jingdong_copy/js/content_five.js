$(function(){
	
	$("#content_five").find(".common-self-rotation").find(".common-self-rotation-control-item").on("mouseover",function(){
		
		$(this).parent().find(".common-self-rotation-control-item").css("background","white");
		var colorValue = $(this).parent().parent().parent().parent().parent().css("border-top-color");
		$(this).css("background",colorValue);
		
		$(this).parent().parent().find("img").hide();
		$(this).parent().parent().find("img").eq($(this).attr("title")).show();
	});
	
	$("#content_five").find(".common-self-rotation").find(".common-self-rotation-control-item").on("click",function(){
		
		$(this).parent().find(".common-self-rotation-control-item").css("background","white");
		var colorValue = $(this).parent().parent().parent().parent().parent().css("border-top-color");
		$(this).css("background",colorValue);
		
		$(this).parent().parent().find("img").hide();
		$(this).parent().parent().find("img").eq($(this).attr("title")).show();
	});
	
	/* 初始化页面 */
	$("#content_five").find(".common-self-rotation").find(".common-self-rotation-control-item").eq(0).click();
	
	var indexContentFiveOne = 0;
		
	setInterval(function(){
		
		if(indexContentFiveOne>$("#content_five").find(".common-self-rotation").eq(0).find(".common-self-rotation-control-item").length-2){
			indexContentFiveOne = 0;
		}else{
			indexContentFiveOne++;
		}
		$("#content_five").find(".common-self-rotation").eq(0).find(".common-self-rotation-control-item").eq(indexContentFiveOne).click();
		
	},5000);
	
	var indexContentFiveTwo = 0;
		
	setInterval(function(){
		
		if(indexContentFiveTwo>$("#content_five").find(".common-self-rotation").eq(1).find(".common-self-rotation-control-item").length-2){
			indexContentFiveTwo = 0;
		}else{
			indexContentFiveTwo++;
		}
		$("#content_five").find(".common-self-rotation").eq(1).find(".common-self-rotation-control-item").eq(indexContentFiveTwo).click();
		
	},4000);
	
	var indexContentFiveThree = 0;
		
	setInterval(function(){
		
		if(indexContentFiveThree>$("#content_five").find(".common-self-rotation").eq(2).find(".common-self-rotation-control-item").length-2){
			indexContentFiveThree = 0;
		}else{
			indexContentFiveThree++;
		}
		$("#content_five").find(".common-self-rotation").eq(2).find(".common-self-rotation-control-item").eq(indexContentFiveThree).click();
		
	},4500);
	
	var indexContentFiveFour = 0;
		
	setInterval(function(){
		
		if(indexContentFiveFour>$("#content_five").find(".common-self-rotation").eq(3).find(".common-self-rotation-control-item").length-2){
			indexContentFiveFour = 0;
		}else{
			indexContentFiveFour++;
		}
		$("#content_five").find(".common-self-rotation").eq(3).find(".common-self-rotation-control-item").eq(indexContentFiveFour).click();
		
	},4700);
	
	
	
	$("#content_five").find(".common-self-rotation").find("img").hide();
	
	var commonRotationArr = $("#content_five").find(".common-self-rotation");
	for(var i=0;i<commonRotationArr.length;i++){
		commonRotationArr.eq(i).find("img").eq(0).show();
	}
	
	/*slider control*/
	$("#content_five").find(".left-right-slider").find(".left-slider-control").on("click",function(){
		
		var contentArr = $(this).parent().find(".left-right-slider-content");
		contentArr.hide();
		if($(this).attr("title")<=0){
			$(this).attr("title",0);
		}else{
			$(this).attr("title",$(this).attr("title")-1);
		}
		contentArr.eq($(this).attr("title")).show();
	});
	
	$("#content_five").find(".left-right-slider").find(".right-slider-control").on("click",function(){
		var contentArr = $(this).parent().find(".left-right-slider-content");
		contentArr.hide();
		if($(this).attr("title")>=contentArr.length-1){
			$(this).attr("title",contentArr.length-1);
		}else{
			$(this).attr("title",$(this).attr("title")+1);
		}
		contentArr.eq($(this).attr("title")).show();
	});
	
	
	$("#content_five").find(".left-right-slider").find(".left-right-slider-content").hide();
	$("#content_five").find(".left-right-slider").find(".left-slider-control").click();
	
});