$(function(){
	
	var commonSliders = $(".common-slider");
	
	commonSliders.find(".common-slider-content").hide();
	
	commonSliders.find(".common-slider-control").on("mouseover",function(){
		$(this).parent().parent().find(".common-slider-content").hide();
		$(this).parent().parent().find(".common-slider-content").eq($(this).attr("title")).show();
		
		$(this).css("background","#3b46b0");
		$(this).css("color","white");
	});
	
	commonSliders.find(".common-slider-control").on("click",function(){
		$(this).parent().parent().find(".common-slider-content").hide();
		$(this).parent().parent().find(".common-slider-content").eq($(this).attr("title")).show();
		
	});
	
	commonSliders.find(".common-slider-control-style-one").on("mouseover",function(){
		
		$(".common-slider").find(".common-slider-control-style-one").css("background","lightgrey");
		$(".common-slider").find(".common-slider-control-style-one").css("color","#3b46b0");
		
		$(this).css("background","#3b46b0");
		$(this).css("color","white");
	});
	
	commonSliders.find(".common-slider-control-style-one").on("click",function(){
		
		$(".common-slider").find(".common-slider-control-style-one").css("background","lightgrey");
		$(".common-slider").find(".common-slider-control-style-one").css("color","#3b46b0");
		
		$(this).css("background","#3b46b0");
		$(this).css("color","white");
	});
	
	commonSliders.find(".common-slider-control").eq(0).click();
	commonSliders.find(".common-slider-control-style-one").eq(0).click();
	
});