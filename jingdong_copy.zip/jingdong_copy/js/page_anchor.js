$(function(){
	
	$("#page_anchor").hide();
	
	$("#page_anchor").find("div").on("mouseover",function(){
		$("#page_anchor").css("width","7.5em");
		$("#page_anchor").find(".description").show();
		$("#page_anchor").find("div").css("color","black");
		$(this).css("color","#009f96");
	});
	$("#page_anchor").on("mouseout",function(){
		$("#page_anchor").css("width","2.5em");
		$("#page_anchor").find(".description").hide();
	});
	
	$(window).scroll(function(){
        var h=$(this).scrollTop();
        if(h<10){
        	$("#page_anchor").hide();
        }
        if(h>=10){
        	/* 左滑动显示内容  */
        	$("#page_anchor").find(".description").hide();
        	$("#page_anchor").css("width","2.5em");
        	$("#page_anchor").show();
        }
    });
});