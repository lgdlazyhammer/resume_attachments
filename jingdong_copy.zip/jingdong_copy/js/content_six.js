$(function(){
	
	$("#content_six").find(".content-six-item").hide();
	$("#content_six").find(".content-six-item").eq(0).show();
		
		
	var contentSixarr = $("#content_six").find(".content-six-control");
	contentSixarr.on("mouseover",function(){
		
		$("#content_six").find(".content-six-item").hide();
		$("#content_six").find(".content-six-item").eq($(this).attr("title")).show();
		
		var controlArr = $("#content_six").find(".content-six-control");
		controlArr.removeClass("widder");
		$(this).addClass("widder");
		
		controlArr.removeClass("styleone styletwo stylethree stylefour stylefive");
		
		switch(parseInt($(this).attr("title"))){
			case 0: controlArr.addClass("styleone");break;
			case 1: controlArr.addClass("styletwo");break;
			case 2: controlArr.addClass("stylethree");break;
			case 3: controlArr.addClass("stylefour");break;
			case 4: controlArr.addClass("stylefive");break;
		}
	});
	
});