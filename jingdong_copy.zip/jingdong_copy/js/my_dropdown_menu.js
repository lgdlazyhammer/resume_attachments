$(function(){
	var arr = $(".header-item");
	arr.find(".my-drowdown-menu").hide();
	arr.find(".my-drowdown-menu-right").hide();
	
	arr.on("mouseover",function(){
		var menu = $(this).find(".my-drowdown-menu");
		var content = menu.find(".content");
		content.css("position","absolute");
		content.css("top","0%");
		content.css("left","0%");
		content.css("z-index","1111");
		content.css("border-left","solid 1px lightgrey");
		content.css("border-bottom","solid 1px lightgrey");
		content.css("border-right","solid 1px lightgrey");
		content.css("background","#ffffff");
		$(this).css("border-top","solid 1px lightgrey");
		$(this).css("border-left","solid 1px lightgrey");
		$(this).css("border-right","solid 1px lightgrey");
		$(this).css("border-bottom","none");
		$(this).css("background","#ffffff");
		menu.show();
		
		
		$(this).on("mouseleave",function(){
			$(this).css("border","none");
			$(this).css("background","#f1f1f1");
			menu.hide();
		});
		menu.on("mouseleave",function(){
			$(this).hide();
		});
	});
	
	arr.on("mouseover",function(){
		var menu = $(this).find(".my-drowdown-menu-right");
		var content = menu.find(".content");
		content.css("position","absolute");
		content.css("top","100%");
		content.css("right","-2em");
		content.css("z-index","1111");
		content.css("border-left","solid 1px lightgrey");
		content.css("border-bottom","solid 1px lightgrey");
		content.css("border-right","solid 1px lightgrey");
		content.css("background","#ffffff");
		$(this).css("border-top","solid 1px lightgrey");
		$(this).css("border-left","solid 1px lightgrey");
		$(this).css("border-right","solid 1px lightgrey");
		$(this).css("border-bottom","none");
		$(this).css("background","#ffffff");
		menu.show();
		
		
		$(this).on("mouseleave",function(){
			$(this).css("border","none");
			$(this).css("background","#f1f1f1");
			menu.hide();
		});
		menu.on("mouseleave",function(){
			$(this).hide();
		});
	});
});