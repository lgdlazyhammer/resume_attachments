$(function(){
	
	/* 初始化组件   */
	var arrRotation = $("#self_rotation_component");
	arrRotation.find("img").hide();
	arrRotation.find("img").eq(0).show();
	arrRotation.attr("title",0);
	/* 隐藏圆心 */
	$(".slef_rotation_component_control").find("div").hide();
	$(".slef_rotation_component_control").eq(0).find("div").show();
	
	/* 轮播 */
	setInterval(function(){
		var tempItem = $("#self_rotation_component");
		var index = tempItem.attr("title");
		var count = tempItem.find("img").length;
		
		if(index<count-1){
			index++;
		}else{
			index = 0;
		}
		tempItem.attr("title",index);
		tempItem.find("img").hide();
		tempItem.find("img").eq(index).show();
		/* 显示圆心 */
		$(".slef_rotation_component_control").find("div").hide();
		$(".slef_rotation_component_control").eq(index).find("div").show();
	},5000);
	
	/* 轮播控制 */
	var arrRotationControl = $(".slef_rotation_component_control");
	arrRotationControl.on("click",function(){
		var index = $(this).attr("title");
		var tempItem = $("#self_rotation_component");
		tempItem.attr("title",index);
		tempItem.find("img").hide();
		tempItem.find("img").eq(index).show();
		/* 显示圆心 */
		$(".slef_rotation_component_control").find("div").hide();
		$(this).find("div").show();
	});
});
