$(function(){
	/* 左边栏显示隐藏 */
	//$("#content-one-left-home-application").hide();
	$("#content-one-left-living-room-anchor").on("mouseover",function(){
		$("#content-one-left-home-application").hide();
		$("#content-one-left-living-room").show();
		
		$("#content-one-left-home-application-anchor").css("background","#009f96");
		$(this).css("background","#01c0be");
	});
	
	$("#content-one-left-home-application-anchor").on("mouseover",function(){
		$("#content-one-left-living-room").hide();
		$("#content-one-left-home-application").show();
		
		$("#content-one-left-living-room-anchor").css("background","#009f96");
		$(this).css("background","#01c0be");
	});
	
	/* 隐藏弹出框 */
	var arrDialogs = $(".living-room-dialog");
	$("#living-scene-dialog").hide();
	arrDialogs.find(".living-room-dialog-content").hide();
	/* 弹出框显示隐藏 */
	arrDialogs.on("mouseleave",function(){
		$("#living-scene-dialog").hide();
	});
	
	$("#living-scene-dialog").on("mouseleave",function(){
		$(this).hide();
	});
	
	$("#living-scene-dialog").on("mouseover",function(){
		$(this).show();
	});
	
	arrDialogs.on("mouseover",function(){
		var content = $(this).find(".living-room-dialog-content");
		$("#living-scene-dialog").html(content.html());
		$("#living-scene-dialog").show();
		
		$(this).css("background","#009f96");
		
		/*$(this).on("mouseleave",function(){
			$("#living-scene-dialog").hide();
		});*/
	});
	
	arrDialogs.on("mouseleave",function(){
		$(this).css("background","#01c0be");
	});
	/* 弹出框显示隐藏 */
	
	var appDialogsArr = $(".home-application-dialog");
	appDialogsArr.on("mouseover",function(){
		$(this).css("background","#009f96");
		
		var content = $(this).find(".home-application-dialog-content");
		content.css("position","absolute");
		content.css("left","100%");
		content.css("top","0px");
		content.css("z-index","1111");
		content.show();
		
		content.on("mouseleave",function(){
			$(this).hide();
		});
		
		$(this).on("mouseleave",function(){
			content.hide();
		});
	});
	
	appDialogsArr.on("mouseleave",function(){
		$(this).css("background","#01c0be");
	});
	
});