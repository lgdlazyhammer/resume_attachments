$(function(){
	
	var contentSub = $(".content-one-sub-pure");
		contentSub.find(".panel-selector-content-item").hide();
	var arrControls = contentSub.find(".panel-selector-control");
	
	arrControls.on("mouseover",function(){
		
		var contentArr = $(".content-one-sub-pure");
		contentArr.find(".panel-selector-control").css("border","none");
		contentArr.find(".panel-selector-control").css("border-bottom","solid 2px #009f96");
		contentArr.find(".panel-selector-control").css("color","rgba(133,133,133,1)");
		//border-top:solid 2px #009f96;
		$(this).css("border-left","solid 2px #009f96");
		$(this).css("border-right","solid 2px #009f96");
		$(this).css("border-top","solid 2px #009f96");
		$(this).css("border-bottom","none");
		
		$(this).css("color","#009f96");
		
		var content = $(".content-one-sub-pure");
		content.find(".panel-selector-content-item").hide();
		content.find(".panel-selector-content-item").eq($(this).attr("title")).show();
		
		/*$(".panel-selector-content-item .img-div").on("mouseover",function(){
			$(this).css("trasition","right 2s");
			$(this).css("right","3em");
		});
		
		$(".panel-selector-content-item .img-div").on("mouseleave",function(){
			$(this).css("trasition","right 2s");
			$(this).css("right","0em");
		});*/
	});
	
	arrControls.on("click",function(){
		
		var contentArr = $(".content-one-sub-pure");
		contentArr.find(".panel-selector-control").css("border","none");
		contentArr.find(".panel-selector-control").css("border-bottom","solid 2px #009f96");
		contentArr.find(".panel-selector-control").css("color","rgba(133,133,133,1)");
		//border-top:solid 2px #009f96;
		$(this).css("border-left","solid 2px #009f96");
		$(this).css("border-right","solid 2px #009f96");
		$(this).css("border-top","solid 2px #009f96");
		$(this).css("border-bottom","none");
		
		$(this).css("color","#009f96");
		
		var content = $(".content-one-sub-pure");
		content.find(".panel-selector-content-item").hide();
		content.find(".panel-selector-content-item").eq($(this).attr("title")).show();
	});
		
	/* 页面初始化  */
	arrControls.eq(0).click();
	
});